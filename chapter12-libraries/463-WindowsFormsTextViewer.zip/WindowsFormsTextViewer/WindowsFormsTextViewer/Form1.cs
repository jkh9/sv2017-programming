﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsTextViewer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btOpen_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
            string name = openFileDialog1.FileName;
            string[] lines = File.ReadAllLines(name);
            foreach (var l in lines)
            {
                listBox1.Items.Add(l);
            }
        }

        private void trackBar1_ValueChanged(object sender, EventArgs e)
        {
            listBox1.Font = new Font(
                listBox1.Font.FontFamily, 
                trackBar1.Value);
        }
    }
}
