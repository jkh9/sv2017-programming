﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsSumTwoNumbers
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btCalculate_Click(object sender, EventArgs e)
        {
            long n1 = 0, n2 = 0;
            if ( ! long.TryParse(tbFirstNumber.Text, out n1))
            {
                tbSum.Text = "First number not correct";
            }
            else if (!long.TryParse(tbSecondNumber.Text, out n2))
            {
                tbSum.Text = "Second number not correct";
            }
            else
            {
                try
                {
                    tbSum.Text = (n1 + n2).ToString();
                }
                catch
                {
                    tbSum.Text = "Error!";
                }
            }
        }

        private void tbSum_TextChanged(object sender, EventArgs e)
        {

        }

        private void tbSecondNumber_TextChanged(object sender, EventArgs e)
        {

        }

        private void lbSecondNumber_Click(object sender, EventArgs e)
        {

        }

        private void tbFirstNumber_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
