﻿namespace WindowsFormsSumTwoNumbers
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbFirstNumber = new System.Windows.Forms.Label();
            this.tbFirstNumber = new System.Windows.Forms.TextBox();
            this.tbSecondNumber = new System.Windows.Forms.TextBox();
            this.lbSecondNumber = new System.Windows.Forms.Label();
            this.tbSum = new System.Windows.Forms.TextBox();
            this.lbSum = new System.Windows.Forms.Label();
            this.btCalculate = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbFirstNumber
            // 
            this.lbFirstNumber.AutoSize = true;
            this.lbFirstNumber.Location = new System.Drawing.Point(37, 31);
            this.lbFirstNumber.Name = "lbFirstNumber";
            this.lbFirstNumber.Size = new System.Drawing.Size(66, 13);
            this.lbFirstNumber.TabIndex = 0;
            this.lbFirstNumber.Text = "First Number";
            // 
            // tbFirstNumber
            // 
            this.tbFirstNumber.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbFirstNumber.Location = new System.Drawing.Point(118, 23);
            this.tbFirstNumber.Name = "tbFirstNumber";
            this.tbFirstNumber.Size = new System.Drawing.Size(163, 20);
            this.tbFirstNumber.TabIndex = 1;
            this.tbFirstNumber.TextChanged += new System.EventHandler(this.tbFirstNumber_TextChanged);
            // 
            // tbSecondNumber
            // 
            this.tbSecondNumber.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbSecondNumber.Location = new System.Drawing.Point(118, 60);
            this.tbSecondNumber.Name = "tbSecondNumber";
            this.tbSecondNumber.Size = new System.Drawing.Size(163, 20);
            this.tbSecondNumber.TabIndex = 3;
            this.tbSecondNumber.TextChanged += new System.EventHandler(this.tbSecondNumber_TextChanged);
            // 
            // lbSecondNumber
            // 
            this.lbSecondNumber.AutoSize = true;
            this.lbSecondNumber.Location = new System.Drawing.Point(37, 68);
            this.lbSecondNumber.Name = "lbSecondNumber";
            this.lbSecondNumber.Size = new System.Drawing.Size(84, 13);
            this.lbSecondNumber.TabIndex = 2;
            this.lbSecondNumber.Text = "Second Number";
            this.lbSecondNumber.Click += new System.EventHandler(this.lbSecondNumber_Click);
            // 
            // tbSum
            // 
            this.tbSum.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbSum.Location = new System.Drawing.Point(119, 114);
            this.tbSum.Name = "tbSum";
            this.tbSum.ReadOnly = true;
            this.tbSum.Size = new System.Drawing.Size(163, 20);
            this.tbSum.TabIndex = 5;
            this.tbSum.TextChanged += new System.EventHandler(this.tbSum_TextChanged);
            // 
            // lbSum
            // 
            this.lbSum.AutoSize = true;
            this.lbSum.Location = new System.Drawing.Point(38, 122);
            this.lbSum.Name = "lbSum";
            this.lbSum.Size = new System.Drawing.Size(28, 13);
            this.lbSum.TabIndex = 4;
            this.lbSum.Text = "Sum";
            // 
            // btCalculate
            // 
            this.btCalculate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btCalculate.Location = new System.Drawing.Point(206, 164);
            this.btCalculate.Name = "btCalculate";
            this.btCalculate.Size = new System.Drawing.Size(75, 23);
            this.btCalculate.TabIndex = 6;
            this.btCalculate.Text = "Calculate";
            this.btCalculate.UseVisualStyleBackColor = true;
            this.btCalculate.Click += new System.EventHandler(this.btCalculate_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(304, 209);
            this.Controls.Add(this.btCalculate);
            this.Controls.Add(this.tbSum);
            this.Controls.Add(this.lbSum);
            this.Controls.Add(this.tbSecondNumber);
            this.Controls.Add(this.lbSecondNumber);
            this.Controls.Add(this.tbFirstNumber);
            this.Controls.Add(this.lbFirstNumber);
            this.MinimumSize = new System.Drawing.Size(320, 240);
            this.Name = "Form1";
            this.Text = "SuperAdder V1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbFirstNumber;
        private System.Windows.Forms.TextBox tbFirstNumber;
        private System.Windows.Forms.TextBox tbSecondNumber;
        private System.Windows.Forms.Label lbSecondNumber;
        private System.Windows.Forms.TextBox tbSum;
        private System.Windows.Forms.Label lbSum;
        private System.Windows.Forms.Button btCalculate;
    }
}

