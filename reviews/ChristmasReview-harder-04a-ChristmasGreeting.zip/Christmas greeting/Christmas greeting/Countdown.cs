﻿using System;
using SDL2;
public class Countdown{
    protected uint start;
    protected uint end;

    public event Action CountdownEventHandler;
    public Countdown() { }

    public void Reset()
    {
        start = SDL.SDL_GetTicks();
    }
    public void IsTime(uint time)
    {
        end = SDL.SDL_GetTicks();
        if ((end - start) >= time)
        {
            CountdownEventHandler.Invoke();
            Reset();
        }
            
    }
}
