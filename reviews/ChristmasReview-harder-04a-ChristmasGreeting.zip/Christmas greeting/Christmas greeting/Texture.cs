﻿using System;
using SDL2;
public class Texture{
    protected IntPtr texture;

    public int Width { get; set; }
    public int Height { get; set; }

    public IntPtr Txtr
    {
        get { return texture; }
        set { texture = value; }
    }
    public Texture()
    {
        texture = (IntPtr)null;
    }

    public bool CreateTexture(IntPtr renderer,string path, int w,int h)
    {
        IntPtr surface = SDL_image.IMG_Load(path);
        if (surface == null)
            Console.WriteLine(SDL.SDL_GetError());
        else
        {
            texture = SDL.SDL_CreateTextureFromSurface(renderer,surface);

            if(texture == null)
                Console.WriteLine(SDL.SDL_GetError());
            else
            {
                Width = w;
                Height = h;
            }

            SDL.SDL_FreeSurface(surface);
        }

        return texture != null;
    }

    public unsafe bool CreateTTF(IntPtr renderer,IntPtr font,string text,SDL.SDL_Color color)
    {
        SDL.SDL_Surface* surface = 
            (SDL.SDL_Surface*)SDL_ttf.TTF_RenderText_Solid(font, text, color);
        if (surface == null)
            Console.WriteLine(SDL.SDL_GetError());
        else
        {
            texture = SDL.SDL_CreateTextureFromSurface(renderer,(IntPtr)surface);

            if (texture == null)
                Console.WriteLine(SDL.SDL_GetError());
            else
            {
                Width = surface->w;
                Height = surface->h;
            }

            SDL.SDL_FreeSurface((IntPtr)surface);
        }

        return texture != null;
    }

    public void RenderTexture(IntPtr renderer,
        SDL.SDL_Rect clip,SDL.SDL_Rect rect,double angle = 0)
    {
        SDL.SDL_Point point = new SDL.SDL_Point() { x = Width / 2, y = Height / 2 };

        SDL.SDL_RenderCopyEx
            (renderer,texture,ref clip,ref rect,angle,
            ref point,SDL.SDL_RendererFlip.SDL_FLIP_NONE);
    }

    public void RenderTexture(IntPtr renderer,int x = 0,int y = 0,double angle = 0)
    {
        SDL.SDL_Point point = new SDL.SDL_Point() { x = Width / 2, y = Height / 2 };
        SDL.SDL_Rect rect = new SDL.SDL_Rect() { x = x, y = y, w = Width, h = Height };
        SDL.SDL_Rect clip = new SDL.SDL_Rect() { x = 0, y = 0, w = Width, h = Height };

        SDL.SDL_RenderCopyEx
            (renderer, texture, ref clip, ref rect, angle,
            ref point, SDL.SDL_RendererFlip.SDL_FLIP_NONE);
    }

    /*public void Free()
    {
        SDL.SDL_FreeSurface(Txtr);
    }*/
}
