﻿using System;
using SDL2;
public class MovingEntity {
    protected Texture texture;
    protected int posX;
    protected int posY;
    protected int velX;
    protected int velY;
    protected double angle;
    protected SDL.SDL_Rect spriteClip;

    public MovingEntity(IntPtr renderer,IntPtr font,string text)
    {
        Random rnd = new Random();
        texture = new Texture();
        texture.CreateTTF(renderer, font, text,
            new SDL.SDL_Color
            {
                r = (byte)rnd.Next(0, 256),
                g = (byte)rnd.Next(0, 256),
                b = (byte)rnd.Next(0, 256),
                a = 255
            });

        spriteClip = new SDL.SDL_Rect()
            { x = 0, y = 0, w = texture.Width, h = texture.Height };
        angle = 0;
    }

    public MovingEntity
        (Texture reference, int velX, int velY, int posX, int posY)
    {
        texture = new Texture
        {
            Txtr = reference.Txtr,
            Width = reference.Width,
            Height = reference.Height,
        };

        this.posX = posX;
        this.posY = posY;
        this.velX = velX;
        this.velY = velY;

        spriteClip = new SDL.SDL_Rect()
            { x = 0, y = 0, w = texture.Width, h = texture.Height };
        angle = 0;
    }

    public virtual void Move() { }

    public void Render(IntPtr renderer)
    {
        SDL.SDL_Rect hitbox = new SDL.SDL_Rect()
            { x = posX, y = posY, w = texture.Width, h = texture.Height };
        texture.RenderTexture
            (renderer, spriteClip, hitbox, angle);
    }
}
