﻿//Lee primero lo que hay en la clase Program.cs que es la que tiene el Main

using System;
using System.Collections.Generic;
using SDL2;

public enum TexureNum : int
    { R_ball,G_ball,B_ball,Y_ball,SnowF_1,SnowF_2,Back,Merry,Lose,Restart,Exit}

public class Game {
    public static int SCREEN_WIDTH = 640;
    public static int SCREEN_HEIGHT = 480;

    private IntPtr screen;
    private IntPtr renderer;
    private IntPtr font;
    private SDL.SDL_Event gameEvent;

    private Texture[] gameTextures;

    private SnowGenerator snowG;
    private Scoreboard sb;
    private List<Ball> balls;
    private Countdown generateBallTimer;
    private uint ballSpawnTime;

    public Game()
    {
        balls = new List<Ball>();
        gameTextures = new Texture[11];
        generateBallTimer = new Countdown();
        generateBallTimer.CountdownEventHandler += AddBall;
        ballSpawnTime = 4000;

        for (int i = 0; i < 11; i++)
            gameTextures[i] = new Texture();

        snowG = new SnowGenerator(1000, gameTextures[4], gameTextures[5]);
        
    } 

    public void Init()
    {
        SDL.SDL_SetHint(SDL.SDL_HINT_WINDOWS_DISABLE_THREAD_NAMING, "1");
        if (SDL.SDL_Init(SDL.SDL_INIT_EVERYTHING) < 0)
        {
            Console.WriteLine(SDL.SDL_GetError());
        }
        else {
            if(SDL_image.IMG_Init(SDL_image.IMG_InitFlags.IMG_INIT_PNG) != 2)
            {
                Console.WriteLine(SDL.SDL_GetError());
            }
            else { 
                if(SDL_ttf.TTF_Init() != 0)
                {
                    Console.WriteLine(SDL.SDL_GetError());
                }
                else { 
                    screen = SDL.SDL_CreateWindow("Christmas greeting",
                        SDL.SDL_WINDOWPOS_UNDEFINED, SDL.SDL_WINDOWPOS_UNDEFINED, 
                        SCREEN_WIDTH,SCREEN_HEIGHT,SDL.SDL_WindowFlags.SDL_WINDOW_SHOWN);

                    renderer = SDL.SDL_CreateRenderer(screen, -1, 
                        SDL.SDL_RendererFlags.SDL_RENDERER_PRESENTVSYNC);

                    SDL.SDL_SetRenderDrawColor(renderer, 0x00, 0x00, 0x00, 0xff);

                    if(LoadTextures())
                        PlayGame();
                    else
                        Console.WriteLine("Couldn't load textures");

                    Quit();
                }
            }
        }
    }

    private bool LoadTextures()
    {
        if ((font = SDL_ttf.TTF_OpenFont(@"ttf\font.ttf", 50)) == null)
            return false;

        sb = new Scoreboard(renderer, font);

        if (!gameTextures[(int)TexureNum.R_ball].
            CreateTexture(renderer, @"images\red_ball.png", 70, 70))
            return false;

        if (!gameTextures[(int)TexureNum.G_ball].
            CreateTexture(renderer, @"images\green_ball.png", 50, 50))
            return false;

        if (!gameTextures[(int)TexureNum.B_ball].
            CreateTexture(renderer, @"images\blue_ball.png", 50, 50))
            return false;

        if (!gameTextures[(int)TexureNum.Y_ball].
            CreateTexture(renderer,@"images\yellow_ball.png", 30, 30))
            return false;

        if (!gameTextures[(int)TexureNum.SnowF_1].
            CreateTexture(renderer, @"images\snowflake1.png", 9, 9))
            return false;

        if (!gameTextures[(int)TexureNum.SnowF_2].
            CreateTexture(renderer, @"images\snowflake2.png", 9, 9))
            return false;

        if (!gameTextures[(int)TexureNum.Back].CreateTexture
            (renderer, @"images\background.png", SCREEN_WIDTH, SCREEN_HEIGHT))
            return false;

        if (!gameTextures[(int)TexureNum.Merry].CreateTTF
            (renderer, font, "Merry Christmas", 
            new SDL.SDL_Color { r = 0x00, g = 0x00, b = 0x00, a = 0xff }))
            return false;

        if (!gameTextures[(int)TexureNum.Lose].CreateTTF
            (renderer, font, "You Lose!",
            new SDL.SDL_Color { r = 0xff, g = 0x00, b = 0x00, a = 0xff }))
            return false;

        if (!gameTextures[(int)TexureNum.Restart].CreateTTF
            (renderer, font, "Press Enter to restart",
            new SDL.SDL_Color { r = 0xff, g = 0xff, b = 0x00, a = 0xff }))
            return false;

        if (!gameTextures[(int)TexureNum.Exit].CreateTTF
            (renderer, font, "Press Escape to exit",
            new SDL.SDL_Color { r = 0x00, g = 0xff, b = 0xff, a = 0xff }))
            return false;

        return true;
    }
    private void PlayGame()
    {
        bool exitGame = false;

        generateBallTimer.Reset();

        while (!exitGame)
        {
            if(SDL.SDL_PollEvent(out gameEvent) != 0)
            {
                if (gameEvent.type == SDL.SDL_EventType.SDL_QUIT)
                    exitGame = true;
                if (gameEvent.type == SDL.SDL_EventType.SDL_MOUSEBUTTONDOWN)
                    RemoveBall();
                if (gameEvent.type == SDL.SDL_EventType.SDL_KEYDOWN &&
                    gameEvent.key.keysym.sym == SDL.SDL_Keycode.SDLK_s)
                    snowG.OnOff();
            }
            SDL.SDL_RenderClear(renderer);

            generateBallTimer.IsTime(ballSpawnTime);
            gameTextures[(int)TexureNum.Back].RenderTexture(renderer);
            gameTextures[(int)TexureNum.Merry].
                RenderTexture(renderer,10,
                SCREEN_HEIGHT / 2 - gameTextures[(int)TexureNum.Merry].Height / 2);
            RenderBalls();
            sb.RenderScore(renderer,0,0);
            sb.RenderPoints(renderer);
            snowG.Generate(renderer);

            if(balls.Count > 8)
            {
                LoseGameScreen(ref exitGame);
            }
            SDL.SDL_RenderPresent(renderer);
        }

    }

    private void LoseGameScreen(ref bool exitGame)
    {
        bool exitScreen = false;
        balls.Clear();
        snowG.Reset();

        while (!exitScreen)
        {
            if (SDL.SDL_PollEvent(out gameEvent) != 0)
            {
                if (gameEvent.type == SDL.SDL_EventType.SDL_QUIT 
                    || (gameEvent.type == SDL.SDL_EventType.SDL_KEYDOWN &&
                    gameEvent.key.keysym.sym == SDL.SDL_Keycode.SDLK_ESCAPE))
                { 
                    exitGame = true;
                    exitScreen = true;
                }
                if (gameEvent.type == SDL.SDL_EventType.SDL_KEYDOWN &&
                    gameEvent.key.keysym.sym == SDL.SDL_Keycode.SDLK_RETURN)
                {
                    exitScreen = true;
                }

            }
            SDL.SDL_RenderClear(renderer);

            gameTextures[(int)TexureNum.Back].RenderTexture(renderer);

            sb.RenderScore(renderer,0,0);
            gameTextures[(int)TexureNum.Lose].
                RenderTexture(renderer,
                SCREEN_WIDTH / 2 - gameTextures[(int)TexureNum.Lose].Width / 2,
                SCREEN_HEIGHT / 6 - gameTextures[(int)TexureNum.Lose].Height / 2);

            gameTextures[(int)TexureNum.Restart].
                RenderTexture(renderer,
                SCREEN_WIDTH / 2 - gameTextures[(int)TexureNum.Restart].Width / 2,
                SCREEN_HEIGHT / 3 - gameTextures[(int)TexureNum.Restart].Height / 2);

            gameTextures[(int)TexureNum.Exit].
                RenderTexture(renderer,
                SCREEN_WIDTH / 2 - gameTextures[(int)TexureNum.Exit].Width / 2,
                SCREEN_HEIGHT / 2 - gameTextures[(int)TexureNum.Exit].Height / 2);

            SDL.SDL_RenderPresent(renderer);
        }
        sb.Reset(renderer, font);
    }

    private void RenderBalls()
    {
        for (int i = 0; i < balls.Count; i++)
        {
            balls[i].Move();
            balls[i].Render(renderer);
        }
    }
  
    private void AddBall()
    {
        Random rnd = new Random();
        int posX = 0,posY = 0,velX = 0,velY = 0,radius = 0,score = 0;
        int ballColor = rnd.Next(0, 4);
    
        switch (ballColor)
        {
            case 0:
                velX = velY = rnd.Next(1, 3);
                posX = rnd.Next(0, SCREEN_WIDTH - 70);
                posY = rnd.Next(0, SCREEN_HEIGHT - 70);
                radius = 35;
                score = 10;
                break;
            case 1:
            case 2:
                velX = velY = rnd.Next(2, 5);
                posX = rnd.Next(0, SCREEN_WIDTH - 50);
                posY = rnd.Next(0, SCREEN_HEIGHT - 50);
                radius = 25;
                score = 25;
                break;
            case 3:
                velX = velY = rnd.Next(3, 6);
                posX = rnd.Next(0, SCREEN_WIDTH - 30);
                posY = rnd.Next(0, SCREEN_HEIGHT - 30);
                radius = 15;
                score = 50;
                break;
        }
    
        if (rnd.Next(0, 2) == 0)
            velX = -velX;
        if (rnd.Next(0, 2) == 0)
            velY = -velY;
    
        Ball newBall = new Ball(gameTextures[ballColor],velX,velY,posX,posY,radius,score);
        balls.Add(newBall);
    }

    private double Hypotenuse(int a,int b)
    {
        return Math.Sqrt(Math.Abs(a * a) + Math.Abs(b * b));
    }

    private bool MouseInsideBall(Ball ball,int x,int y)
    {
        if(Hypotenuse(ball.CenterX - x,ball.CenterY - y) <= ball.Radius)
            return true;
        return false;
    }

    private void RemoveBall()
    {
        SDL.SDL_GetMouseState(out int mx, out int my);

        for(int i=0; i < balls.Count; i++)
        {
            if (MouseInsideBall(balls[i], mx, my))
            {
                sb.TotalScore += balls[i].BallScore;
                sb.AddPoint(renderer,font,"+" + balls[i].BallScore.ToString());
                balls.Remove(balls[i]);
                ballSpawnTime -= 50;
                if (ballSpawnTime < 1000)
                    ballSpawnTime = 1000;
            }
        }
    }

    private void Quit()
    {
        SDL.SDL_Quit();
        SDL_image.IMG_Quit();
    }
}
