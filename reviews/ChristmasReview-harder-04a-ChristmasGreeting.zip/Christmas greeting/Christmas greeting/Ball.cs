﻿using System;
using SDL2;
class Ball : MovingEntity{
    protected SDL.SDL_Point center;

    public int CenterX { get { return center.x; } }
    public int CenterY { get { return center.y; } }
    public int Radius { get; set; }
    public int BallScore { get; set; }

    public Ball
        (Texture reference, int velX, int velY, int posX, int posY, int radius,int score) :
        base(reference,velX,velY,posX,posY)
    {
        Radius = radius;

        center = new SDL.SDL_Point()
            { x = posX + radius, y = posY + radius };

        BallScore = score;
    }

    public override void Move()
    {
        posX += velX;
        posY += velY;

        center.x = posX + Radius;
        center.y = posY + Radius;

        if (posX + texture.Width >= Game.SCREEN_WIDTH
            || posX <= 0)
            velX = -velX;

        if (posY + texture.Height >= Game.SCREEN_HEIGHT
            || posY <= 0)
            velY = -velY;

        angle += Math.Abs(velX);
    }
}
