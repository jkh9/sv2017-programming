﻿using System;
using System.Collections.Generic;
using SDL2;

class Scoreboard {
    protected Texture scoreTexture;
    protected List<ScorePoint> points;

    public int TotalScore { get; set; }

    public Scoreboard(IntPtr renderer,IntPtr font)
    {
        TotalScore = 0;
        points = new List<ScorePoint>();

        scoreTexture = new Texture();
        scoreTexture.CreateTTF(renderer, font, "Score:" + TotalScore.ToString(),
            new SDL.SDL_Color { r = 0x00, g = 0xff, b = 0xff, a = 0xff });
    }

    public void AddPoint(IntPtr renderer, IntPtr font, string amount)
    {
        points.Add(new ScorePoint(renderer,font,amount));
        scoreTexture.CreateTTF(renderer, font, "Score: " + TotalScore.ToString(),
            new SDL.SDL_Color { r = 0x00, g = 0xff, b = 0xff, a = 0xff });
    }

    public void RenderScore(IntPtr renderer,int x,int y)
    {
        scoreTexture.RenderTexture(renderer,x,y);
    }

    public void RenderPoints(IntPtr renderer)
    {
        for (int i = 0; i < points.Count; i++)
        {
            points[i].Move();
            points[i].Render(renderer);

            if (points[i].IsDead)
                points.Remove(points[i]);
        }
    }
    
    public void Reset(IntPtr renderer,IntPtr font)
    {
        points.Clear();
        TotalScore = 0;
        scoreTexture.CreateTTF(renderer, font, "Score:" + TotalScore.ToString(),
            new SDL.SDL_Color { r = 0x00, g = 0xff, b = 0xff, a = 0xff });
    }

    ~Scoreboard() {
        points.Clear();
    }
}
