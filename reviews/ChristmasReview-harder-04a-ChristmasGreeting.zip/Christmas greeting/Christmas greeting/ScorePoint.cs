﻿using System;
using SDL2;

class ScorePoint : MovingEntity{
    protected byte alpha;

    public bool IsDead { get; set; }

    public ScorePoint(IntPtr renderer,IntPtr font,string score) : base (renderer,font,score)
    {
        angle = 0;
        velX = 0;
        velY = 0;
        IsDead = false;

        SDL.SDL_GetMouseState(out posX,out posY);
        posX -= texture.Width / 2;
        posY -= texture.Height / 2;

        alpha = 255;

        SDL.SDL_SetTextureBlendMode(texture.Txtr, SDL.SDL_BlendMode.SDL_BLENDMODE_BLEND); 
    }

    public override void Move()
    {
        SDL.SDL_SetTextureAlphaMod(texture.Txtr, alpha);
        if (!IsDead)
        {
            alpha -= 5;
            if (alpha <= 0)
                IsDead = true;
        }
    }
}

