﻿using System;
using System.Collections.Generic;
class SnowGenerator{
    protected List<Snowflake> snowflakes;
    protected Texture[] snowflakesTexture;
    protected Countdown timer;
    protected uint snowDelay;

    public bool IsOn { get; set; }

    public SnowGenerator(uint delay,params Texture[] references)
    {
        snowflakes = new List<Snowflake>();
        snowflakesTexture = new Texture[references.Length];

        for(int i = 0;i < references.Length; i++)
        {
            snowflakesTexture[i] = new Texture();
            snowflakesTexture[i] = references[i];
        }

        snowDelay = delay;
        IsOn = true;

        timer = new Countdown();
        timer.CountdownEventHandler += AddSnowflakes;
    }

    private void MoveSnowflakes(IntPtr renderer)
    {
        for (int i = 0; i < snowflakes.Count; i++)
        {
            snowflakes[i].Move();
            snowflakes[i].Render(renderer);
            if (snowflakes[i].IsDead)
                snowflakes.Remove(snowflakes[i]);
        }
    }

    private void AddSnowflakes()
    {
        Random rnd = new Random();
        int quantity = rnd.Next(5,20);
        int posY = -9;

        for(int i=0; i < quantity; i++)
        {
            Snowflake sf = new Snowflake
                (snowflakesTexture[rnd.Next(0, snowflakesTexture.Length)], 0, rnd.Next(1,5),
                rnd.Next(0, Game.SCREEN_WIDTH - 9), posY,rnd.Next(0,200));
            snowflakes.Add(sf);
        }
    }

    public void Generate(IntPtr renderer)
    {
        if (IsOn)
        {
            timer.IsTime(snowDelay);
        }

        if (snowflakes.Count > 0)
        {
            MoveSnowflakes(renderer);
        }
    }

    public void OnOff()
    {
        if(IsOn)
            timer.Reset();
        IsOn = !IsOn;
    }

    public void Reset()
    {
        snowflakes.Clear();
    }
}
