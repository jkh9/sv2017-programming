﻿
class Snowflake : MovingEntity{
    public bool IsDead { get; set; }

    public Snowflake
        (Texture reference, int velX, int velY, int posX, int posY,int angle) :
        base(reference,velX,velY,posX,posY)
    {
        IsDead = false;
        this.angle = angle;
    }

    public override void Move()
    {
        posY += velY;
        angle += velY;

        if (posY  >= Game.SCREEN_HEIGHT - 4)
            IsDead = true;
    }
}
