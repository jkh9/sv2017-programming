﻿//Victor Tebar
//4."Felicitacion navideña"
/* Lo tienes que compilar con la opcion de Permitir codigo no seguro,
 * sino te va a dar error, ya que a la hora de crear una textura a partir
 * de un ttf tengo que usar un puntero(SDL_Surface*) para saber su ancho y largo.
 * Bueno como me aburria, más que una felicitacion es un juego. Tienes que darle
 * click a las bolas conforme van apareciendo. Las bolas aparecen cada cierto tiempo,
 * que va disminuyendo conforme les haces click.
 * Las bolas rojas son las mas lentas y las mas grandes pero solo dan 10 puntos.
 * Las azules y verdes son de mediano tamaño, un poco mas rapidas y dan 25 puntos.
 * Las amarillas son las mas pequeñas y rapidas, y dan 50 puntos.
 * Cuando se acumulan mas de 8 bolas en pantalla pierdes.
 * La nieve se activa/desactiva a la 's'
 * No esperes un código limpio ya que lo he hecho conforme se me iba ocurriendo
 * sin planificación alguna, por lo que muchas cosas estaran mal. De hecho no hace
 * falta ni que lo corrijas, ya que he tenido que escribirlo todo desde 0 y me daba
 * pereza poner comentarios para algo que nunca volvere a tocar.
 * Se que la generación de las bolas podria haberla hecho en una clase aparte 
 * (Que herede de una clase generador, de la que heredaria tambien SnowGenerator) pero
 * empece a hacerla en la principal y me da pereza cambiarlo.
 */

public class Program
{
    public static void Main()
    {
        Game newGame = new Game();
        newGame.Init();
    }
}

