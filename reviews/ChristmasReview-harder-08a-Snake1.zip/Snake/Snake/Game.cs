﻿using System;

class Game{
    private ushort gameSpeed;
    private byte gameLives;
    private byte numObstacles;
    private byte numFruits;
    private byte mapWidth;
    private byte mapHeight;

    private Menu menu;
    private Scoreboard sb;
    private Map map;
    private SnakeEntity snake;

    public Game()
    {
        menu = new Menu();
        Console.CursorVisible = false;
    }

    public void Init()
    {
        int difficulty,mapSize;

        do
        {
            mapSize = menu.MapSizeMenu();
            difficulty = menu.DifficultyMenu();
            SetMapSize(mapSize);
            SetDifficulty(difficulty);

            sb = new Scoreboard(mapWidth, mapHeight, gameLives);

            PlayGame();

            if(sb.Level == 0)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("You win.");
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("You lose.");
            }
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("SCORE: ");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine(sb.Score);
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("LEVEL: ");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine(sb.Level);

            Console.WriteLine("Play again?(Yes/No)");

            Console.ResetColor();
        } while (Console.ReadLine().ToLower() != "no");
    }

    private void PlayGame()
    {
        Console.Clear();
        snake = new SnakeEntity(mapWidth, mapHeight);

        map = new Map(mapWidth, mapHeight, numObstacles, numFruits);
        map.Draw();
        sb.Draw();

        while (sb.Lives != 0 && sb.Level != 0)
        {
            snake.GetKey();

            snake.Draw();

            map.DrawFruit();

            System.Threading.Thread.Sleep(gameSpeed);

            snake.Move();

            if (snake.CheckFruit(map))
            {
                sb.AddScore(map.GetFruitScore());
                snake.Grow();
                map.GenerateFruit();

                if (map.EnoughtFruits())
                {
                    Console.Clear();
                    sb.AddLevel(1);
                    if (sb.Level % 5 == 0)
                        sb.AddLives(1);
                    sb.Draw();
                    map = new Map(mapWidth, mapHeight, numObstacles, numFruits);
                    map.Draw();
                    snake.Respawn();
                }
            }
            else if (snake.CheckHit(map))
            {
                sb.AddLives(-1);
                snake.Respawn();
            }
        }
        Console.Clear();
    }

    private void SetMapSize(int option)
    {
        switch (option)
        {
            case 1:
                mapWidth = 30;
                mapHeight = 15;
                numObstacles = 10;
                if (Console.WindowHeight < 15)
                    Console.WindowHeight = 15;
                if (Console.WindowWidth < 63)
                    Console.WindowWidth = 63;
                break;
            case 2:
                mapWidth = 50;
                mapHeight = 20;
                numObstacles = 25;
                if (Console.WindowHeight < 20)
                    Console.WindowHeight = 20;
                if(Console.WindowWidth < 83)
                    Console.WindowWidth = 83;
                break;
            case 3:
                mapWidth = 70;
                mapHeight = 25;
                numObstacles = 60;
                if (Console.WindowHeight < 25)
                    Console.WindowHeight = 25;
                if (Console.WindowWidth < 103)
                    Console.WindowWidth = 103;
                break;
        }
    }

    private void SetDifficulty(int option)
    {
        switch (option)
        {
            case 1:
                gameSpeed = 150;
                numFruits = 10;
                gameLives = 5;
                break;
            case 2:
                gameSpeed = 120;
                numFruits = 15;
                gameLives = 4;
                break;
            case 3:
                gameSpeed = 90;
                numFruits = 20;
                numObstacles += 5;
                gameLives = 3;
                break;
            case 4:
                gameSpeed = 60;
                numFruits = 25;
                numObstacles += 10;
                gameLives = 2;
                break;
        }
    }
}
