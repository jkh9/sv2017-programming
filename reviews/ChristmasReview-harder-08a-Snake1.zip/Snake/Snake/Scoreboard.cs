﻿using System;

public class Scoreboard
{
    protected Coords sbCoords;
    protected byte width;
    protected byte height;
    protected ulong score;
    protected uint level;
    protected byte lives;

    public byte Lives { get { return lives; } }
    public ulong Score { get { return score; } }
    public uint Level { get { return level; } }

    public Scoreboard(byte mapWidth, byte mapHeight, byte lives)
    {
        sbCoords.x = (byte)(mapWidth + 2);
        sbCoords.y = 0;
        width = 30;
        height = mapHeight;
        score = 0;
        level = 1;
        this.lives = lives;
    }

    //Draws the scoreboard
    public void Draw()
    {
        string horizontalLine = new string(' ', width);

        //Draw the top border
        Console.BackgroundColor = ConsoleColor.White;
        Console.SetCursorPosition(sbCoords.x, sbCoords.y);
        Console.WriteLine(horizontalLine);

        //Draw the right border
        for (byte i = 0; i <= height; i++)
        {
            Console.SetCursorPosition(sbCoords.x, i);
            Console.Write(' ');
        }

        //Draw the right border
        for (byte i = 0; i <= height; i++)
        {
            Console.SetCursorPosition(sbCoords.x + width, i);
            Console.Write(' ');
        }

        //Draw the bottom border
        Console.SetCursorPosition(sbCoords.x, sbCoords.y + height + 1);
        Console.WriteLine(horizontalLine + ' ');

        Console.ResetColor();

        //Draw score,level and lives
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.SetCursorPosition(sbCoords.x + width / 2 - 12, height / 7);
        Console.Write("SCORE: " + score);
        Console.ForegroundColor = ConsoleColor.Red;
        Console.SetCursorPosition(sbCoords.x + width / 2 - 12, height / 5);
        Console.Write("LEVEL: " + level);
        Console.ForegroundColor = ConsoleColor.Green;
        Console.SetCursorPosition(sbCoords.x + width / 2 - 12, height / 3);
        Console.Write("LIVES: " + lives);

        Console.ResetColor();
    }

    //Adds score and prints the result
    public void AddScore(byte amount)
    {
        score += amount;
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.SetCursorPosition(sbCoords.x + width / 2 - 12, height / 7);
        Console.Write("SCORE: " + score);
        Console.ResetColor();
    }

    //Adds level and prints the result
    public void AddLevel(byte amount)
    {
        level += amount;
        Console.ForegroundColor = ConsoleColor.Red;
        Console.SetCursorPosition(sbCoords.x + width / 2 - 12, height / 5);
        Console.Write("LEVEL: " + level);
        Console.ResetColor();
    }

    //Adds lives and prints the result
    public void AddLives(sbyte amount)
    {
        lives += (byte)amount;
        if (lives > 100)
            lives = 99;

        Console.ForegroundColor = ConsoleColor.Green;
        Console.SetCursorPosition(sbCoords.x + width / 2 - 12, height / 3);
        Console.Write("LIVES: " + lives);
        Console.ResetColor();
    }
}