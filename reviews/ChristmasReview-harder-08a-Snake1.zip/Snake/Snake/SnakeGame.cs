﻿/* He hecho mi version de la serpiente.
 * Se puede elegir el tamaño del mapa y la dificultad.
 * Los niveles se generan aleatoriamente.
 * El juego se podria decir que termina al llegar al nivel 4294967296(Ya que pasa al nivel 0)
 */
public struct Coords{
    public byte x;
    public byte y;
}

class Program{
    static void Main(){
        Game game = new Game();
        game.Init();
    }
}

