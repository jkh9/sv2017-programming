﻿using System;
using System.Collections.Generic;

public enum SnakeDirection { Up, Right, Down, Left, No_Direction };

public class SnakeEntity
{
    protected SnakeDirection direction;
    protected Coords pos;
    protected Coords spawnPoint;
    protected byte size;
    protected bool newSize;
    protected List<Coords> bodyPositions;
    ConsoleKeyInfo key;

    public SnakeEntity(byte mapWidth, byte mapHeight)
    {
        spawnPoint.x = (byte)(mapWidth / 2);
        spawnPoint.y = (byte)(mapHeight - mapHeight / 8);
        pos = spawnPoint;
        size = 0;
        newSize = false;
        bodyPositions = new List<Coords>();
        direction = SnakeDirection.No_Direction;
    }

    //Move the snake
    public void Move()
    {
        //Removes snake last position
        Console.SetCursorPosition(bodyPositions[size].x, bodyPositions[size].y);
        Console.WriteLine(" ");

        switch (direction)
        {
            case SnakeDirection.Down: pos.y++; break;
            case SnakeDirection.Up: pos.y--; break;
            case SnakeDirection.Left: pos.x--; break;
            case SnakeDirection.Right: pos.x++; break;
            case SnakeDirection.No_Direction: break;
        }

        if (!newSize)
            bodyPositions.Remove(bodyPositions[size]);
        else
        {
            size++;
            newSize = false;
        }
    }

    //Get player key and change the snake direction
    public void GetKey()
    {
        if (Console.KeyAvailable)
        {
            do
            {
                key = Console.ReadKey(true);
            } while (Console.KeyAvailable);

            switch (key.Key)
            {
                case ConsoleKey.UpArrow:
                case ConsoleKey.W:
                    if (direction != SnakeDirection.Down)
                        direction = SnakeDirection.Up;
                    break;

                case ConsoleKey.DownArrow:
                case ConsoleKey.S:
                    if (direction != SnakeDirection.Up)
                        direction = SnakeDirection.Down;
                    break;

                case ConsoleKey.LeftArrow:
                case ConsoleKey.A:
                    if (direction != SnakeDirection.Right)
                        direction = SnakeDirection.Left;
                    break;

                case ConsoleKey.RightArrow:
                case ConsoleKey.D:
                    if (direction != SnakeDirection.Left)
                        direction = SnakeDirection.Right;
                    break;

                case ConsoleKey.Z:
                    newSize = true;
                    break;
            }
        }
    }

    //Draw the snake
    public void Draw()
    {
        Console.SetCursorPosition(pos.x, pos.y);
        Console.ForegroundColor = ConsoleColor.Green;
        Console.Write("O");
        Console.ResetColor();

        bodyPositions.Insert(0, pos);
    }

    //Increases the size of the snake
    public void Grow()
    {
        newSize = true;
    }

    //Checks if the snake has hit his own body, an obstacle or a map border
    public bool CheckHit(Map map)
    {
        //Own body
        foreach (Coords c in bodyPositions)
        {
            if (pos.x == c.x && pos.y == c.y)
                return true;
        }

        //Border
        if (pos.x > map.Width || pos.x < 1 ||
            pos.y > map.Height || pos.y < 1)
            return true;

        //Map obstacle
        return map.CheckHitWithObstacle(pos.x, pos.y);
    }

    //Returns true if the snakes collides with a fruit
    public bool CheckFruit(Map map)
    {
        return map.CheckHitWithFruit(pos.x, pos.y);
    }

    //Reset the snake positions and size
    public void Respawn()
    {
        size = 0;
        newSize = false;
        pos = spawnPoint;

        //Death animation
        Console.ForegroundColor = ConsoleColor.Green;
        for (int i = 0; i < 3; i++)
        {
            foreach (Coords c in bodyPositions)
            {
                Console.SetCursorPosition(c.x, c.y);
                Console.Write("O");
            }
            System.Threading.Thread.Sleep(200);

            foreach (Coords c in bodyPositions)
            {
                Console.SetCursorPosition(c.x, c.y);
                Console.Write(" ");
            }
            System.Threading.Thread.Sleep(200);
        }
        Console.ResetColor();

        bodyPositions.Clear();
        direction = SnakeDirection.No_Direction;
    }
}
