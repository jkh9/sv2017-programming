﻿using System;
using System.Collections.Generic;

public class Map
{
    public byte Width { get; set; }
    public byte Height { get; set; }

    protected byte numObstacles;
    protected List<Coords> obstacles;
    protected Fruit fruit;
    protected byte numFruits;
    protected byte collectedFruits;

    public Map(byte width, byte height, byte numObstacles, byte numFruits)
    {
        Width = width;
        Height = height;
        this.numObstacles = numObstacles;
        this.numFruits = numFruits;
        collectedFruits = 0;

        obstacles = new List<Coords>();

        GenerateObstacles();
        GenerateFruit();
    }

    private bool IsValidCoord(byte x, byte y)
    {
        foreach (Coords c in obstacles)
        {
            //Disable an obstacles to spawn in the same coords of another obstacle
            if (c.x == x && c.y == y)
                return false;

            //Disable an obstacle to appear near another obstacle
            else if (x >= c.x - 1 && x <= c.x + 1
                && y >= c.y - 1 && y <= c.y + 1)
                return false;
        }

        //Disable obstacles to spawn in the player spawnpoint
        if (x == (Width / 2) && y == (Height - Height / 8))
            return false;

        return true;
    }

    //Generates the obstacles of the map randomly
    private void GenerateObstacles()
    {
        Random rnd = new Random();
        byte x, y;
        do
        {

            do
            {
                x = (byte)rnd.Next(2, Width);
                y = (byte)rnd.Next(2, Height);
            } while (!IsValidCoord(x, y));

            obstacles.Add(new Coords { x = x, y = y });
        } while (obstacles.Count < numObstacles);
    }

    //Generates a fruit in a random coord
    public void GenerateFruit()
    {
        Random rnd = new Random();
        byte x, y;
        do
        {
            x = (byte)rnd.Next(2, Width - 2);
            y = (byte)rnd.Next(2, Height - 2);
        } while (!IsValidCoord(x, y));

        fruit = new Fruit(x, y);
    }

    //Draws the fruit
    public void DrawFruit()
    {
        fruit.Draw();
    }

    //Draw the borders of the map
    private void DrawBorders()
    {
        string horizontalWall = new string(' ', Width + 1);
        Random rnd = new Random();

        Console.BackgroundColor = (ConsoleColor)(rnd.Next(1, 15));
        //Draw the top border
        Console.SetCursorPosition(0, 0);
        Console.Write(horizontalWall);

        //Draw the left border
        for (byte i = 0; i <= Height; i++)
            Console.WriteLine(' ');

        //Draw the right border
        for (byte i = 0; i <= Height; i++)
        {
            Console.SetCursorPosition(Width + 1, i);
            Console.Write(' ');
        }

        //Draw the bottom border
        Console.SetCursorPosition(0, Height + 1);
        Console.Write(horizontalWall + " ");

        Console.ResetColor();
    }

    //Draw the obstacles
    private void DrawObstacles()
    {
        Random rnd = new Random();
        Console.BackgroundColor = (ConsoleColor)rnd.Next(1, 16);

        foreach (Coords obs in obstacles)
        {
            Console.SetCursorPosition(obs.x, obs.y);
            Console.Write(' ');
        }

        Console.ResetColor();
    }

    //Draw the map
    public void Draw()
    {
        DrawBorders();
        DrawObstacles();
    }

    //Returns true if the snake coords collides with an obstacle
    public bool CheckHitWithObstacle(byte x, byte y)
    {
        foreach (Coords c in obstacles)
        {
            if (x == c.x && y == c.y)
                return true;
        }

        return false;
    }

    //Returns true if the snake coords collides with a fruit
    public bool CheckHitWithFruit(byte posX, byte posY)
    {
        if (posX == fruit.Pos.x && posY == fruit.Pos.y)
        {
            collectedFruits++;
            return true;
        }
        return false;
    }

    //Returns the score of the current fruit
    public byte GetFruitScore()
    {
        return fruit.ScoreGiven;
    }

    //Checks if the player has collected enought fruits to pass the level
    public bool EnoughtFruits()
    {
        return collectedFruits >= numFruits;
    }
}