﻿using System;
public class Fruit
{
    protected ConsoleColor color;
    protected char type;

    public Coords Pos;
    public byte ScoreGiven { get; set; }

    public Fruit(byte posX, byte posY)
    {
        Random rnd = new Random();

        switch (rnd.Next(0, 4))
        {
            case 0:
                type = 'o';
                color = ConsoleColor.Red;
                ScoreGiven = 25;
                break;

            case 1:
                type = ')';
                color = ConsoleColor.Yellow;
                ScoreGiven = 15;
                break;

            case 2:
                type = '0';
                color = ConsoleColor.DarkGreen;
                ScoreGiven = 10;
                break;

            case 3:
                type = ':';
                color = ConsoleColor.DarkMagenta;
                ScoreGiven = 30;
                break;
        }

        Pos.x = posX;
        Pos.y = posY;
    }

    public void Draw()
    {
        Console.ForegroundColor = color;
        Console.SetCursorPosition(Pos.x, Pos.y);
        Console.Write(type);
        Console.ResetColor();
    }
}
