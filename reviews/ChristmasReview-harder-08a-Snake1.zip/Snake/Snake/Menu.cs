﻿using System;

public class Menu
{
    private static ConsoleKeyInfo key;

    public Menu() { }

    private int GetKey()
    {
        key = Console.ReadKey(true);

        switch (key.Key)
        {
            case ConsoleKey.D1: return 1;
            case ConsoleKey.D2: return 2;
            case ConsoleKey.D3: return 3;
            case ConsoleKey.D4: return 4;
            default: return -1;
        }
    }

    private void DrawDifficultyMenu()
    {
        Console.SetCursorPosition(0, 0);

        Console.ForegroundColor = ConsoleColor.White;
        Console.WriteLine(" Difficulty: ");
        Console.ResetColor();

        Console.WriteLine("┌──────────┐");
        Console.Write("│ ");
        Console.ForegroundColor = ConsoleColor.Green;
        Console.Write("1.Easy   ");
        Console.ResetColor();
        Console.WriteLine("│");
        Console.Write("│ ");
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.Write("2.Normal ");
        Console.ResetColor();
        Console.WriteLine("│");
        Console.Write("│ ");
        Console.ForegroundColor = ConsoleColor.Red;
        Console.Write("3.Hard   ");
        Console.ResetColor();
        Console.WriteLine("│");
        Console.Write("│ ");
        Console.ForegroundColor = ConsoleColor.Magenta;
        Console.Write("4.Extreme");
        Console.ResetColor();
        Console.WriteLine("│");
        Console.WriteLine("└──────────┘");
    }

    public int DifficultyMenu()
    {
        Console.Clear();
        int option;
        DrawDifficultyMenu();
        do
        {
            option = GetKey();
        } while (option < 1 || option > 4);

        return option;
    }

    private void DrawMapSizeMenu()
    {
        Console.SetCursorPosition(0, 0);

        Console.ForegroundColor = ConsoleColor.White;
        Console.WriteLine(" Size: ");

        Console.WriteLine("┌──────────┐");
        Console.Write("│ ");
        Console.Write("1.Small  ");
        Console.WriteLine("│");
        Console.Write("│ ");
        Console.Write("2.Medium ");
        Console.WriteLine("│");
        Console.Write("│ ");
        Console.Write("3.Large  ");
        Console.WriteLine("│");
        Console.WriteLine("└──────────┘");
    }

    public int MapSizeMenu()
    {
        Console.Clear();
        int option;
        DrawMapSizeMenu();
        do
        {
            option = GetKey();
        } while (option < 1 || option > 3);

        return option;
    }
}
