﻿/*
 * Victor, Gonzalo, Miguel Garcia, Miguel Pastor
 * V0.01 --> Making of the classes
 * 
 */

using System;

namespace ProjectAquarium
{
    class Rock : StaticSprite
    {
    }
}
