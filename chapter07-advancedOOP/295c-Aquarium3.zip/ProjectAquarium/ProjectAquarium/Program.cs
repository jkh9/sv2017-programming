﻿/*
 * Victor, Gonzalo, Miguel Garcia, Miguel Pastor
 * V0.01 --> Making of the classes
 * 
 */

using System;

namespace ProjectAquarium
{
    class Program
    {
        static void Main(string[] args)
        {
            Aquarium a = new Aquarium();
            a.Run();
        }
    }
}
