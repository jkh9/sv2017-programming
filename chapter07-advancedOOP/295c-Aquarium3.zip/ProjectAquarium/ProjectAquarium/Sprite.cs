﻿/*
 * Victor, Gonzalo, Miguel Garcia, Miguel Pastor
 * V0.01 --> Making of the classes
 * 
 */

using System;

namespace ProjectAquarium
{
    class Sprite
    {
        protected byte x;
        protected byte y;
        protected string[,] model;

        public void Display()
        {
            // TODO
        }
    }
}
