﻿/*
 * Victor, Gonzalo, Miguel Garcia, Miguel Pastor
 * V0.01 --> Making of the classes
 * 
 */

using System;

namespace ProjectAquarium
{
    class Aquarium
    {
        protected MobileSprite[] mobileObjects;
        protected StaticSprite[] staticObjects;

        public void Run()
        {
            //TODO
        }
    }
}
