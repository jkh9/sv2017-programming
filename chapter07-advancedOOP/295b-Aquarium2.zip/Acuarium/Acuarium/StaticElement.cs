﻿using System;
public class StaticElement
{
    protected int x;
    protected int y;
    protected string sprite;

    public StaticElement(int x, int y, string sprite)
    {
        this.x = x;
        this.y = y;
        this.sprite = sprite;
    }

    public int GetX()
    {
        return x;
    }
    public void SetX(int newX)
    {
        x = newX;
    }
    public int GetY()
    {
        return y;
    }
    public void SetY(int newY)
    {
        y = newY;
    }
    public string GetSprite()
    {
        return sprite;
    }
    public void SetSprite(string newSprite)
    {
        sprite = newSprite;
    }
}