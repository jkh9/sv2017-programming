﻿using System;
class Rock : StaticElement
{
    public Rock(int x, int y, string sprite) : base(x, y, sprite)
    {
    }
    public void Display()
    {
    }

}