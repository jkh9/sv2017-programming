﻿using System;

class Bubble
{
    public Bubble()
    {

    }
}

