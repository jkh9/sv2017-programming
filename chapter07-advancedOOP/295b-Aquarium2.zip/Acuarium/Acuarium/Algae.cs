﻿using System;

class Algae
{
    public Algae()
    {

    }
}
