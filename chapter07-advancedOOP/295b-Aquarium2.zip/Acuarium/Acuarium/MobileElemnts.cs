﻿using System;

class MobileElemnts 
{
    protected int x;
    protected int y;
    protected string sprite;

    public void SetX(int newx)
    {
        x = newx;
    }
    public int GetX()
    {
        return x;
    }
    public void SetY(int newy)
    {
        y = newy;
    }
    public int GetY()
    {
        return y;
    }

    public void SetSprite(string newsprite)
    {
        sprite = newsprite;
    }
    public string GetSprite()
    {
        return sprite;
    }

    public MobileElemnts( int x, int y, string sprite)
    {
        this.x = x;
        this.y = y;
        this.sprite = sprite;
    }

    public MobileElemnts()
    {
        
    }

    public void ShowPosition()
    {
        Console.SetCursorPosition(x, y);
        Console.WriteLine(sprite);
    }
}

