﻿using System;
class Fish 
{

    public Fish()
    {

    }
}

