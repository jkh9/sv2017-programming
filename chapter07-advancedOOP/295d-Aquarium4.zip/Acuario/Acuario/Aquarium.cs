﻿//Guillermo Pator, Javier Cases, Almudena Lopez, Angel Rebollo
class AquariumTest
{
    static void Main()
    {
        Sprite sp = new Sprite();

    }
}
