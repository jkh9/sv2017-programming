﻿//Almudena Lopez, Angel Rebollo, Javier Cases, Guillermo Pastor

class Rock : Static
{
    

    public Rock( string color, int weight)
    {
        this.color = color;
        this.weight = weight;
    }

   
}