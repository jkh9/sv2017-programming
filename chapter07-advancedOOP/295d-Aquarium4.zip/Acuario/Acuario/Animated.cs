﻿//Guillermo Pator, Javier Cases, Almudena Lopez, Angel Rebollo
class Animated : Sprite
{

    public Animated(int x, int y) : base (x, y) { }

    public void SetX(int x) { this.x = x; }
    public void SetY(int y) { this.y = y; }

    public int GetX() { return x; }
    public int GetY() { return y; }



    public void Move()
    {

    }

    public virtual void Display()
    {
        System.Console.Write("");
    }
}
