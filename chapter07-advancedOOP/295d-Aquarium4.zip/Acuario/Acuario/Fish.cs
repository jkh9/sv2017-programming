﻿//Guillermo Pator, Javier Cases, Almudena Lopez, Angel Rebollo

using System;

class Fish : Animated
{
    protected string type;
    protected string color;
    protected int size;

    public Fish(int x, int y, string newType, string newColor, int newSize) 
        : base (x, y)
    {
        type = newType;
        color = newColor;
        size = newSize;
    }

    public void SetType(string newType) { type = newType; }

    public string GetType(string newType) { return type; }

    public void SetColor(string newColor) { color = newColor; }

    public string GetColor() { return color; }

    public void SetSize(int newSize) { size = newSize; }

    public int GetSize() { return size; }

    public override void Display()
    {
        Console.SetCursorPosition(x, y);
        System.Console.WriteLine(">))))D");
    }

}