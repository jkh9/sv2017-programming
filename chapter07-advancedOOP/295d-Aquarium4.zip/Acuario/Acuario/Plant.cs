﻿//Guillermo Pator, Javier Cases, Almudena Lopez, Angel Rebollo
using System;
class Plant : Animated
{
    public Plant (int x, int y) : base (x, y) { }

    public override void Display()
    {
        Console.SetCursorPosition(x, y);
        System.Console.WriteLine("|");
    }
}