﻿//Almudena Lopez, Angel Rebollo, Javier Cases, Guillermo Pastor

class Static : Sprite
{
    protected string color;
    protected int weight;

    public void SetColor(string newcolor)
    {
        color = newcolor;
    }

    public void SetWeight(int newweight)
    {
        weight = newweight;
    }

    public string GetColor()
    {
        return color;
    }

    public int GetWeight()
    {
        return weight;
    }
}