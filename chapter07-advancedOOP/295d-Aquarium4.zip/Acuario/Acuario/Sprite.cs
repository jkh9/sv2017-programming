﻿//Guillermo Pator, Javier Cases, Almudena Lopez, Angel Rebollo

class Sprite
{
    protected int x, y;
    protected char image;

    public Sprite (int x, int y)
    {
        this.x = x;
        this.y = y;
    }
    protected Animated animated = new Animated(1, 1);
    protected Still still = new Still();

    public void Draw()
    {
        
    }
}