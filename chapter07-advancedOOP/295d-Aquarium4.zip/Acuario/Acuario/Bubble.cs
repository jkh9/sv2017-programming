﻿//Guillermo Pator, Javier Cases, Almudena Lopez, Angel Rebollo
using System;

class Bubble : Animated
{
    public Bubble(int x, int y) : base (x, y) { }

    public override void Display()
    {
        Console.SetCursorPosition(x, y);
        System.Console.WriteLine("O");
    }
}