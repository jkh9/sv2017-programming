﻿//Almudena Lopez, Angel Rebollo, Javier Cases, Guillermo Pastor
using System;

class Coral
{
}

