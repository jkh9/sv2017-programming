﻿// Javier Saorín Vidal, Querubin Santana, Francisco Sabater,
// Renata Pestana Ribeiro, Cesar Martín, Luis Sellés
using System;

class Plants : Animated
{
    public Plants(int x, int y, string[,] sprite) : base(x, y, sprite)
    {
    }
}
