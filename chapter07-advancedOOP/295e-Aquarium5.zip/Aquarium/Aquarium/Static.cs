﻿class Static
{
    protected int zindex;

    public Static(int zindex)
    {
        this.zindex = zindex;
    }

    public void SetZindex(int newzindex)
    {
        zindex = newzindex;
    }

    public int GetZindex()
    {
        return zindex;
    }
}

class SunkenShip : Static
{

    public SunkenShip(int zindex) : base(zindex)
    {

    }

}

class Rock : Static
{
    public Rock(int zindex) : base(zindex)
    {

    }
}

class Coral : Static
{
    public Coral(int zindex) : base(zindex)
    {

    }
}
