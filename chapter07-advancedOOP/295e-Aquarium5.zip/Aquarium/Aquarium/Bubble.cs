﻿using System;
class Bubble : Animated
{

    protected int diameter;
    protected int up;

    public Bubble(int x, int y, string[,] sprite) : base(x, y, sprite)
    {
    }

    public void MoveTo(int x, int y, int up)
    {
        this.diameter = diameter;
        this.x = x;
        this.y = y;
        this.up = up;
    }
    public int GetDiameter()
    {
        return diameter;
    }
    public void GetUp()
    {

    }

    public void SetDiameter(int diameter)
    {
        this.diameter = diameter;
    }

    public void SetUp(int newUp)
    {
        this.up = newUp;
    }
}
public class AquariumTest
{
    public static void Main()
    {
        Bubble[] bubbles = new Bubble[10];

        Random r = new Random();
        for (int i = 0; i < 10; i++)
        {
            int size = r.Next(0, 40);
        }
    }

}
