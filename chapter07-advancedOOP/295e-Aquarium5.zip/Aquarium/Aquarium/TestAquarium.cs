﻿// Javier Saorín Vidal, Querubin Santana, Francisco Sabater, Renata Pestana Ribeiro
class TestAquarium
{
    static void Main()
    {
        Aquarium aquarium = new Aquarium();
        aquarium.Run();
    }
}
