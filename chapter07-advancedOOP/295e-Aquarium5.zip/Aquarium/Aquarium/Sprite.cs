﻿// Javier Saorín Vidal, Querubin Santana, Francisco Sabater,
// Renata Pestana Ribeiro, Cesar Martín, Luis Sellés
class Sprite
{
    protected int x, y;
    protected string[,] sprite;

    public Sprite(int x, int y, string[,] sprite)
    {
        this.x = x;
        this.y = y;
        this.sprite = sprite;
    }
}
