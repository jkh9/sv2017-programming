﻿// Javier Saorín Vidal, Querubin Santana, Francisco Sabater,
// Renata Pestana Ribeiro, Cesar Martín, Luis Sellés
class Animated : Sprite
{
    public Animated(int x, int y, string[,] sprite) : base(x, y, sprite)
    {
    }

    public virtual void Move(int newX, int newY)
    {
        x = newX;
        y = newY;
    }
}
