﻿
class Leg
{
    protected string color;
    protected int heightMm;

    public Leg(string newColor, int newHeightMm)
    {
        color = newColor;
        heightMm = newHeightMm;
    }

    public Leg(int newHeightMm)
    {
        color = "black";
        heightMm = newHeightMm;
    }

    public void SetColor(string newColor)
    {
        color = newColor;
    }

    public string GetColor()
    {
        return color;
    }

    public void SetHeight(int newHeightMm)
    {
        heightMm = newHeightMm;
    }

    public int GetHeight()
    {
        return heightMm;
    }

    public void ShowStatus()
    {
        System.Console.WriteLine("I am a leg");
        System.Console.WriteLine("My color is " + color);
        System.Console.WriteLine("My height is " + heightMm);
    }
}
