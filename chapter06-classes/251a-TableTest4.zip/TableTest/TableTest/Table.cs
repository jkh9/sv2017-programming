﻿
class Table
{
    protected Leg myLeg;
    protected string color;
    protected bool open;

    public Table( string newColor, Leg newLeg)
    {
        color = newColor;
        myLeg = newLeg;
        open = true;
    }

    public void SetLeg(Leg newLeg)
    {
        myLeg = newLeg;
    }

    public Leg GetLeg()
    {
        return myLeg;
    }

    public void SetColor(string newColor)
    {
        color = newColor;
    }

    public string GetColor()
    {
        return color;
    }

    public bool IsOpen()
    {
        return open;
    }

    public void Open()
    {
        open = true;
    }

    public void Close()
    {
        open = false;
    }

    public void ShowStatus()
    {
        System.Console.WriteLine("I am a table");
        System.Console.WriteLine("My color is " + color);
        System.Console.WriteLine("Open? " + open);
        System.Console.WriteLine("About my leg...");
        myLeg.ShowStatus();
    }
}
