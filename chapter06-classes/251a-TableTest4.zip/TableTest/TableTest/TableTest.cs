﻿/*

New in this version:

Leg:
- color: get, set
- height: get, set
- constructors: 
    color, height
    height("black")

Table:
- attribute "open"
- Leg: get, set
- constructors: 
    color, Leg
*/


class TableTest
{
    static void Main(string[] args)
    {
        Leg l = new Leg("red", 750);
        l.ShowStatus();
        l.SetHeight(740);
        l.SetColor("maroon");
        l.ShowStatus();

        Table t = new Table("white", l);
        t.ShowStatus();

        t.SetColor("grey");
        t.Close();
        t.ShowStatus();
    }
}
