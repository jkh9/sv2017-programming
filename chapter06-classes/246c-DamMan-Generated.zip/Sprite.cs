// FILE: C:/Users/Alumno/Desktop//Sprite.cs

// In this section you can add your own using directives
    // section -64--88-0-60--770fe847:1605036f521:-8000:000000000000087E begin
    // section -64--88-0-60--770fe847:1605036f521:-8000:000000000000087E end

/// <summary>
    ///  A class that represents ...
    /// 
    ///  @see OtherClasses
    ///  @author your_name_here
     /// </summary>
public class Sprite
{
    // Attributes

    public Integer x;

    public Integer y;

    public Boolean visible;

    // Operations

    /// <summary>
    ///  An operation that does...
    /// 
    ///  @param firstParam a description of this parameter
    /// </summary>
    /// <returns>
    /// </returns>
    public  void Move()
    {
    // section -64--88-0-60--770fe847:1605036f521:-8000:000000000000087F begin
    // section -64--88-0-60--770fe847:1605036f521:-8000:000000000000087F end

    }

    /// <summary>
    ///  An operation that does...
    /// 
    ///  @param firstParam a description of this parameter
    /// </summary>
    /// <returns>
    /// </returns>
    public  void Display()
    {
    // section -64--88-0-60--770fe847:1605036f521:-8000:00000000000008C7 begin
    // section -64--88-0-60--770fe847:1605036f521:-8000:00000000000008C7 end

    }

    /// <summary>
    ///  An operation that does...
    /// 
    ///  @param firstParam a description of this parameter
    /// </summary>
    /// <param name="x">
    /// </param>
    /// <param name="y">
    /// </param>
    /// <returns>
    /// </returns>
    public  void MoveTo(Integer x, Integer y)
    {
    // section -64--88-0-60--770fe847:1605036f521:-8000:00000000000008CC begin
    // section -64--88-0-60--770fe847:1605036f521:-8000:00000000000008CC end

    }
} /* end class Sprite */
