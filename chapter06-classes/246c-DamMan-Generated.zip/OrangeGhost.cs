// FILE: C:/Users/Alumno/Desktop//OrangeGhost.cs

// In this section you can add your own using directives
    // section -64--88-0-60--770fe847:1605036f521:-8000:000000000000087C begin
    // section -64--88-0-60--770fe847:1605036f521:-8000:000000000000087C end

/// <summary>
    ///  A class that represents ...
    /// 
    ///  @see OtherClasses
    ///  @author your_name_here
     /// </summary>
public class OrangeGhost : Ghost
{
    // Associations

    /// <summary> 
    /// </summary>
    public ArrayList  myGame;
} /* end class OrangeGhost */
