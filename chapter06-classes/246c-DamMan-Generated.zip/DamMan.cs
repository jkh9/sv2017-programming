// FILE: C:/Users/Alumno/Desktop//DamMan.cs

// In this section you can add your own using directives
    // section -64--88-0-60--770fe847:1605036f521:-8000:0000000000000866 begin
    // section -64--88-0-60--770fe847:1605036f521:-8000:0000000000000866 end

/// <summary>
    ///  A class that represents ...
    /// 
    ///  @see OtherClasses
    ///  @author your_name_here
     /// </summary>
public class DamMan
{
    // Attributes

    public Integer maxScore;

    // Associations

    /// <summary> 
    /// </summary>
    public ArrayList  myGame;

    /// <summary> 
    /// </summary>
    public ArrayList  myWelcomeScreen;

    // Operations

    /// <summary>
    ///  An operation that does...
    /// 
    ///  @param firstParam a description of this parameter
    /// </summary>
    /// <returns>
    /// </returns>
    public  void Run()
    {
    // section -64--88-0-60--770fe847:1605036f521:-8000:000000000000086A begin
    // section -64--88-0-60--770fe847:1605036f521:-8000:000000000000086A end

    }
} /* end class DamMan */
