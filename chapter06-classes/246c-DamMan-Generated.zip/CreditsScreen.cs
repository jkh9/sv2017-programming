// FILE: C:/Users/Alumno/Desktop//CreditsScreen.cs

// In this section you can add your own using directives
    // section -64--88-0-60--770fe847:1605036f521:-8000:0000000000000898 begin
    // section -64--88-0-60--770fe847:1605036f521:-8000:0000000000000898 end

/// <summary>
    ///  A class that represents ...
    /// 
    ///  @see OtherClasses
    ///  @author your_name_here
     /// </summary>
public class CreditsScreen
{
    // Associations

    /// <summary> 
    /// </summary>
    public ArrayList  myWelcomeScreen;

    // Operations

    /// <summary>
    ///  An operation that does...
    /// 
    ///  @param firstParam a description of this parameter
    /// </summary>
    /// <returns>
    /// </returns>
    public  void Run()
    {
    // section -64--88-0-60--770fe847:1605036f521:-8000:000000000000089B begin
    // section -64--88-0-60--770fe847:1605036f521:-8000:000000000000089B end

    }
} /* end class CreditsScreen */
