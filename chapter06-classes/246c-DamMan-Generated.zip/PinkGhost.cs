// FILE: C:/Users/Alumno/Desktop//PinkGhost.cs

// In this section you can add your own using directives
    // section -64--88-0-60--770fe847:1605036f521:-8000:00000000000008B5 begin
    // section -64--88-0-60--770fe847:1605036f521:-8000:00000000000008B5 end

/// <summary>
    ///  A class that represents ...
    /// 
    ///  @see OtherClasses
    ///  @author your_name_here
     /// </summary>
public class PinkGhost : Ghost
{} /* end class PinkGhost */
