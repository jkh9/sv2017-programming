// FILE: C:/Users/Alumno/Desktop//WelcomeScreen.cs

// In this section you can add your own using directives
    // section -64--88-0-60--770fe847:1605036f521:-8000:0000000000000872 begin
    // section -64--88-0-60--770fe847:1605036f521:-8000:0000000000000872 end

/// <summary>
    ///  A class that represents ...
    /// 
    ///  @see OtherClasses
    ///  @author your_name_here
     /// </summary>
public class WelcomeScreen
{
    // Associations

    /// <summary> 
    /// </summary>
    public ArrayList  myDamMan;

    /// <summary> 
    /// </summary>
    public ArrayList  myCreditsScreen;

    /// <summary> 
    /// </summary>
    public ArrayList  myHiScoresScreen;

    /// <summary> 
    /// </summary>
    public ArrayList  myDemoScreen;

    /// <summary> 
    /// </summary>
    public ArrayList  myDemoScreen;

    /// <summary> 
    /// </summary>
    public ArrayList  myDemoScreen;

    // Operations

    /// <summary>
    ///  An operation that does...
    /// 
    ///  @param firstParam a description of this parameter
    /// </summary>
    /// <returns>
    /// </returns>
    public  void Run()
    {
    // section -64--88-0-60--770fe847:1605036f521:-8000:0000000000000879 begin
    // section -64--88-0-60--770fe847:1605036f521:-8000:0000000000000879 end

    }
} /* end class WelcomeScreen */
