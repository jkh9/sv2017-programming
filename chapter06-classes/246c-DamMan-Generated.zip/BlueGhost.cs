// FILE: C:/Users/Alumno/Desktop//BlueGhost.cs

// In this section you can add your own using directives
    // section -64--88-0-60--770fe847:1605036f521:-8000:00000000000008B6 begin
    // section -64--88-0-60--770fe847:1605036f521:-8000:00000000000008B6 end

/// <summary>
    ///  A class that represents ...
    /// 
    ///  @see OtherClasses
    ///  @author your_name_here
     /// </summary>
public class BlueGhost : Ghost
{} /* end class BlueGhost */
