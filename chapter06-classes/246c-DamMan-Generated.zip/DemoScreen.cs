// FILE: C:/Users/Alumno/Desktop//DemoScreen.cs

// In this section you can add your own using directives
    // section -64--88-0-60--770fe847:1605036f521:-8000:000000000000089D begin
    // section -64--88-0-60--770fe847:1605036f521:-8000:000000000000089D end

/// <summary>
    ///  A class that represents ...
    /// 
    ///  @see OtherClasses
    ///  @author your_name_here
     /// </summary>
public class DemoScreen
{
    // Associations

    /// <summary> 
    /// </summary>
    public ArrayList  myWelcomeScreen;

    /// <summary> 
    /// </summary>
    public ArrayList  myWelcomeScreen;

    /// <summary> 
    /// </summary>
    public ArrayList  myWelcomeScreen;

    // Operations

    /// <summary>
    ///  An operation that does...
    /// 
    ///  @param firstParam a description of this parameter
    /// </summary>
    /// <returns>
    /// </returns>
    public  void Run()
    {
    // section -64--88-0-60--770fe847:1605036f521:-8000:00000000000008AD begin
    // section -64--88-0-60--770fe847:1605036f521:-8000:00000000000008AD end

    }
} /* end class DemoScreen */
