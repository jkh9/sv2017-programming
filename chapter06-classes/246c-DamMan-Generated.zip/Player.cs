// FILE: C:/Users/Alumno/Desktop//Player.cs

// In this section you can add your own using directives
    // section -64--88-0-60--770fe847:1605036f521:-8000:000000000000088C begin
    // section -64--88-0-60--770fe847:1605036f521:-8000:000000000000088C end

/// <summary>
    ///  A class that represents ...
    /// 
    ///  @see OtherClasses
    ///  @author your_name_here
     /// </summary>
public class Player : Sprite
{
    // Associations

    /// <summary> 
    /// </summary>
    public ArrayList  myGame;

    // Operations

    /// <summary>
    ///  An operation that does...
    /// 
    ///  @param firstParam a description of this parameter
    /// </summary>
    /// <returns>
    /// </returns>
    public  void MoveRight()
    {
    // section -64--88-0-60--770fe847:1605036f521:-8000:0000000000000890 begin
    // section -64--88-0-60--770fe847:1605036f521:-8000:0000000000000890 end

    }

    /// <summary>
    ///  An operation that does...
    /// 
    ///  @param firstParam a description of this parameter
    /// </summary>
    /// <returns>
    /// </returns>
    public  void MoveLeft()
    {
    // section -64--88-0-60--770fe847:1605036f521:-8000:0000000000000892 begin
    // section -64--88-0-60--770fe847:1605036f521:-8000:0000000000000892 end

    }

    /// <summary>
    ///  An operation that does...
    /// 
    ///  @param firstParam a description of this parameter
    /// </summary>
    /// <returns>
    /// </returns>
    public  void MoveUp()
    {
    // section -64--88-0-60--770fe847:1605036f521:-8000:0000000000000894 begin
    // section -64--88-0-60--770fe847:1605036f521:-8000:0000000000000894 end

    }

    /// <summary>
    ///  An operation that does...
    /// 
    ///  @param firstParam a description of this parameter
    /// </summary>
    /// <returns>
    /// </returns>
    public  void MoveDown()
    {
    // section -64--88-0-60--770fe847:1605036f521:-8000:0000000000000896 begin
    // section -64--88-0-60--770fe847:1605036f521:-8000:0000000000000896 end

    }
} /* end class Player */
