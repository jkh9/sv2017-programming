// FILE: C:/Users/Alumno/Desktop//Level.cs

// In this section you can add your own using directives
    // section -64--88-0-60--770fe847:1605036f521:-8000:00000000000008B7 begin
    // section -64--88-0-60--770fe847:1605036f521:-8000:00000000000008B7 end

/// <summary>
    ///  A class that represents ...
    /// 
    ///  @see OtherClasses
    ///  @author your_name_here
     /// </summary>
public class Level
{
    // Associations

    /// <summary> 
    /// </summary>
    public ArrayList  myGame;

    // Operations

    /// <summary>
    ///  An operation that does...
    /// 
    ///  @param firstParam a description of this parameter
    /// </summary>
    /// <param name="x">
    /// </param>
    /// <param name="y">
    /// </param>
    /// <returns>
    /// </returns>
    public  void CanMoveTo( x,  y)
    {
    // section -64--88-0-60--770fe847:1605036f521:-8000:00000000000008BF begin
    // section -64--88-0-60--770fe847:1605036f521:-8000:00000000000008BF end

    }

    /// <summary>
    ///  An operation that does...
    /// 
    ///  @param firstParam a description of this parameter
    /// </summary>
    /// <returns>
    /// </returns>
    public  void IsFinished()
    {
    // section -64--88-0-60--770fe847:1605036f521:-8000:00000000000008C3 begin
    // section -64--88-0-60--770fe847:1605036f521:-8000:00000000000008C3 end

    }

    /// <summary>
    ///  An operation that does...
    /// 
    ///  @param firstParam a description of this parameter
    /// </summary>
    /// <returns>
    /// </returns>
    public  void Display()
    {
    // section -64--88-0-60--770fe847:1605036f521:-8000:00000000000008C5 begin
    // section -64--88-0-60--770fe847:1605036f521:-8000:00000000000008C5 end

    }
} /* end class Level */
