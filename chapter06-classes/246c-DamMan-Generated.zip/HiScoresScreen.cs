// FILE: C:/Users/Alumno/Desktop//HiScoresScreen.cs

// In this section you can add your own using directives
    // section -64--88-0-60--770fe847:1605036f521:-8000:000000000000088B begin
    // section -64--88-0-60--770fe847:1605036f521:-8000:000000000000088B end

/// <summary>
    ///  A class that represents ...
    /// 
    ///  @see OtherClasses
    ///  @author your_name_here
     /// </summary>
public class HiScoresScreen
{
    // Associations

    /// <summary> 
    /// </summary>
    public ArrayList  myWelcomeScreen;

    // Operations

    /// <summary>
    ///  An operation that does...
    /// 
    ///  @param firstParam a description of this parameter
    /// </summary>
    /// <returns>
    /// </returns>
    public  void Run()
    {
    // section -64--88-0-60--770fe847:1605036f521:-8000:0000000000000899 begin
    // section -64--88-0-60--770fe847:1605036f521:-8000:0000000000000899 end

    }
} /* end class HiScoresScreen */
