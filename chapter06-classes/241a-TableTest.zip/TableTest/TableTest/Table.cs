﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableTest
{
    class Table
    {
        Leg myLeg;
        string color;

        public void Open()
        {
            // TO DO
        }

        public void Close()
        {
            // TO DO
        }
    }
}
