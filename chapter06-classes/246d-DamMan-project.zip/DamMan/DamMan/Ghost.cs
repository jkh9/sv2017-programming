// 
// DamMan
// Ghost: The base for the 4 ghosts
//

// Versions:
// V0.01 13-Dic-2017 Nacho: Almost empty skeleton

public class Ghost : Sprite
{
} /* end class Ghost */
