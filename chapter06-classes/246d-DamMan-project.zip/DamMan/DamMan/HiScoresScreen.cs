// 
// DamMan
// HiScoresScreen: Will show the best scores... some day...
//

// Versions:
// V0.01 13-Dic-2017 Nacho: Almost empty skeleton

using System;

public class HiScoresScreen
{

    public void Run()
    {
        Console.WriteLine("Scores...");
        Console.ReadLine();
    }
} /* end class HiScoresScreen */