// 
// DamMan
// OrangeGhost: The orange ghost
//

// Versions:
// V0.01 13-Dic-2017 Nacho: Almost empty skeleton

public class OrangeGhost : Ghost
{

} /* end class OrangeGhost */
