using System;

public class MenuScreen {

  // Operation
  // return 
  public Display ()
  {
    throw new System.Exception ("Not implemented yet!");
  }
  // Operation
  // return int
  public int GetChosenOption ()
  {
    throw new System.Exception ("Not implemented yet!");
  }

}

