using System;


public class Game {

  // Associations 
  private MazeMap unnamed_3;
  private TextInterface unnamed_2;
  private RoomViewer unnamed_1;

  // Operation
  // return 
  public Run ()
  {
    throw new System.Exception ("Not implemented yet!");
  }

}

