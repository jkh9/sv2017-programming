using System;

public class WelcomeScreen {

  // Operation
  // return 
  public Display ()
  {
    throw new System.Exception ("Not implemented yet!");
  }

}

