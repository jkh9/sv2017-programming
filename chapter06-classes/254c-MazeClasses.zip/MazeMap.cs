using System;

public class MazeMap {

  // Operation
  // return string
  public string GetDoors ()
  {
    throw new System.Exception ("Not implemented yet!");
  }

}

