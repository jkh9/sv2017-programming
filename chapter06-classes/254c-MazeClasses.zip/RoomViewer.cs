using System;

public class RoomViewer {

  // Operation
  // return 
  public Display ()
  {
    throw new System.Exception ("Not implemented yet!");
  }

}

