using System;


public class Maze {

  // Associations 
  private Game unnamed_7;
  private WelcomeScreen unnamed_6;
  private CreditsScreen unnamed_5;
  private MenuScreen unnamed_4;

  // Operation
  // return 
  public Run ()
  {
    throw new System.Exception ("Not implemented yet!");
  }

}

