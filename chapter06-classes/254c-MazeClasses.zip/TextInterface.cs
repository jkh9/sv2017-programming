using System;

public class TextInterface {

  // Operation
  // return 
  public Display ()
  {
    throw new System.Exception ("Not implemented yet!");
  }
  // Operation
  // return string
  public string GetCommand ()
  {
    throw new System.Exception ("Not implemented yet!");
  }

}

