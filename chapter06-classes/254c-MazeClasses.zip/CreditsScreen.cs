using System;

public class CreditsScreen {

  // Operation
  // return 
  public Display ()
  {
    throw new System.Exception ("Not implemented yet!");
  }

}

