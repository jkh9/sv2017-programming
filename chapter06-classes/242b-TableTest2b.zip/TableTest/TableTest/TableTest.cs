﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableTest
{
    class TableTest
    {
        static void Main(string[] args)
        {
            Table t = new Table();
            t.SetColor("Red");
            t.Open();
        }
    }
}
