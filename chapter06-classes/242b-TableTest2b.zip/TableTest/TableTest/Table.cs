﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TableTest
{
    class Table
    {
        private Leg myLeg;
        private string color;

        public void SetColor(string newColor)
        {
            color = newColor;
        }

        public string GetColor()
        {
            return color;
        }

        public void Open()
        {
            // TO DO
        }

        public void Close()
        {
            // TO DO
        }
    }
}
