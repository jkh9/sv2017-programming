﻿class Snail : MainCharacter
{
}

