﻿class Sprite
{
    public short X { get; set; }
    public short Y { get; set; }
    public short Width { get; set; }
    public short Height { get; set; }

    public Sprite(short x, short y, short width, short height)
    {
        X = x;
        Y = y;
        Width = width;
        Height = height;
    }
}

