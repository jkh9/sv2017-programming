﻿//Marcos Cervantes, Almudena López, Victor Tébar
//20/04/2018 Version 0.1 - Create class

using System;

public abstract class Screen
{
    public abstract void Display();
}

