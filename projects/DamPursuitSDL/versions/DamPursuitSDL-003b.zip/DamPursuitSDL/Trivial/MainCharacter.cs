﻿class MainCharacter
{
    public int Points { get; set; }

}
