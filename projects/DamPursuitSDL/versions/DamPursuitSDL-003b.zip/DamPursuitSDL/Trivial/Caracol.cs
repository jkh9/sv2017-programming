﻿class Caracol : MainCharacter
{
}

