﻿// V0.01 20-Dic-2017 
// Guillermo Pator, Daniel Miquel, Querubin Santana
// Sabater, Lopez, Rebollo

// V0.02 16-Ene-2018 Nacho: 
//     Renamed from Animated to AnimatedSprite
//     Added constructor

class StaticSprite : Sprite
{
    public StaticSprite(int x, int y, string image)
        : base (x, y, image)
    {
    }
}