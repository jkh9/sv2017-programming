﻿//Guillermo Pator, Daniel Miquel, Querubin Santana
//Sabater, Lopez, Rebollo
class Still : Sprite
{

}