// 
// DamMan
// RedGhost: The red ghost
//

// Versions:
// V0.01 13-Dic-2017 Nacho: Almost empty skeleton

public class RedGhost : Ghost
{
} /* end class RedGhost */
