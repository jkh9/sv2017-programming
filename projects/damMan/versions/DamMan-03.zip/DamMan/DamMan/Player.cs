// 
// DamMan
// Player: PacMan, used by the player  ;-)
//

// Versions:
// V0.01 13-Dic-2017 Nacho: Almost empty skeleton
// V0.03 07-Ene-2018 Nacho: Player can move right

public class Player : Sprite
{
    // Associations

    // public Game  myGame;

    // Operations

    public  void MoveRight()
    {
        // Note: we should check if we can move
        x++;
    }

    public  void MoveLeft()
    {
        // TO DO
    }

    public  void MoveUp()
    {
        // TO DO
    }

    public  void MoveDown()
    {
        // TO DO
    }
} /* end class Player */
