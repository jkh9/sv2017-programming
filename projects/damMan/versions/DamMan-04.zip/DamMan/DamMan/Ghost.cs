// 
// DamMan
// Ghost: The base for the 4 ghosts
//

// Versions:
// V0.01 13-Dic-2017 Nacho: Almost empty skeleton
// v0.04 17-Ene-2018 Luis Sell�s, Brandon Blasco, C�sar Martinez, Tania Pigem:
//            Methods MoveRight, Left, Up, Down (almost empty)

public class Ghost : Sprite
{
    // Associations

    // public Game  myGame;

    // Operations
    public void MoveRight()
    {
        // Note: we should check if we can move
        x++;
    }

    public void MoveLeft()
    {
        // TO DO
    }

    public void MoveUp()
    {
        // TO DO
    }

    public void MoveDown()
    {
        // TO DO
    }
} 
/* end class Ghost */
