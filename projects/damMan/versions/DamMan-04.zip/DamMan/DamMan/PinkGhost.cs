// 
// DamMan
// PinkGhost: The pink ghost
//

// Versions:
// V0.01 13-Dic-2017 Nacho: Almost empty skeleton

public class PinkGhost : Ghost
{
} /* end class PinkGhost */
