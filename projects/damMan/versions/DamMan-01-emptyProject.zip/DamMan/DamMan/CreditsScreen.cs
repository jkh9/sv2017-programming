// 
// DamMan
// CreditsScreen: Credits for the authors
//

// Versions:
// V0.01 13-Dic-2017 Nacho: Almost empty skeleton

using System;

public class CreditsScreen
{

    public void Run()
    {
        Console.WriteLine("Credits!");
        Console.ReadLine();
    }
} /* end class CreditsScreen */