// 
// DamMan
// WelcomeScreen: First thing to display
//

// Versions:
// V0.01 13-Dic-2017 Nacho: Almost empty skeleton

using System;

public class WelcomeScreen
{

    public void Run()
    {
        Console.WriteLine("Welcome!");
        Console.ReadLine();
    }
} /* end class WelcomeScreen */