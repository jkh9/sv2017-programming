// 
// DamMan
// BlueGhost: The blue ghost
//

// Versions:
// V0.01 13-Dic-2017 Nacho: Almost empty skeleton

public class BlueGhost : Ghost
{
} /* end class BlueGhost */
