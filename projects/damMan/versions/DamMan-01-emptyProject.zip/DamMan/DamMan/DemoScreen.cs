// 
// DamMan
// DemoScreen: Shows a bit of the game... or it will do some day...
//

// Versions:
// V0.01 13-Dic-2017 Nacho: Almost empty skeleton

using System;

public class DemoScreen
{

    public void Run()
    {
        Console.WriteLine("Demo!");
        Console.ReadLine();
    }
} /* end class DemoScreen */
