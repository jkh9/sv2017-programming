// FILE: C:/Users/Alumno/Desktop//Player.cs

// In this section you can add your own using directives
    // section -64--88-0-60--770fe847:1605036f521:-8000:000000000000088C begin
    // section -64--88-0-60--770fe847:1605036f521:-8000:000000000000088C end

/// <summary>
    ///  A class that represents ...
    /// 
    ///  @see OtherClasses
    ///  @author your_name_here
     /// </summary>
public class Player : Sprite
{
    // Associations

    // public Game  myGame;

    // Operations

    public  void MoveRight()
    {
        // Note: we should check if we can move
        // x++;
    }

    public  void MoveLeft()
    {
        // TO DO
    }

    public  void MoveUp()
    {
        // TO DO
    }

    public  void MoveDown()
    {
        // TO DO
    }
} /* end class Player */
