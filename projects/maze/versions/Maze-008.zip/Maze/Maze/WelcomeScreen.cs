/*
 *  Maze Game
 * 
 *  V0.07 19-Dic-2017 Nacho: Almost empty skeleton
 */

using System;

public class WelcomeScreen
{

    public void Display()
    {
        Console.Write("Welcome. Press Enter to continue...");
        Console.ReadLine();
    }

}

