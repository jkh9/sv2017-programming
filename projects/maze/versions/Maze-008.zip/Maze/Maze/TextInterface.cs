/*
 *  Maze Game
 * 
 *  V0.07 19-Dic-2017 Nacho: Almost empty skeleton
 */

using System;

public class TextInterface
{

    public void Display()
    {
        throw new System.Exception("Not implemented yet!");
    }

    public string GetCommand()
    {
        throw new System.Exception("Not implemented yet!");
        return "not yet";
    }

}

