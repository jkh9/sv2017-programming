
/*
 *  Maze Game
 * 
 *  V0.07 19-Dic-2017 Nacho: Empty skeleton
 */

using System;

public class MazeMap
{

    public string GetDoors()
    {
        throw new System.Exception("Not implemented yet!");
        return "1";
    }

}

