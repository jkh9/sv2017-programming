/*
 *  Maze Game
 * 
 *  V0.07 19-Dic-2017 Nacho: Empty skeleton
 */

using System;

public class RoomViewer
{

    public void Display()
    {
        throw new System.Exception("Not implemented yet!");
    }

}

