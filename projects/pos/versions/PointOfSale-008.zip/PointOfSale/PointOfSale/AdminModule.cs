﻿// 
// Point of sale
//

// Versions:
// V0.08 19-Dic-2017 Nacho: Empty skeleton

using System;

public class AdminModule
{
    public void Run()
    {
        // TO DO
    }
}
