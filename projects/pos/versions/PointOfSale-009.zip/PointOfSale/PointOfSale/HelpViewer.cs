﻿// 
// Point of sale
//

// Versions:
// V0.08 19-Dic-2017 Nacho: Almost empty skeleton

using System;

class HelpViewer
{
    public void DisplayHelp(string fileName)
    {
        Console.WriteLine("Supposedly watching the help file...");
    }
}
