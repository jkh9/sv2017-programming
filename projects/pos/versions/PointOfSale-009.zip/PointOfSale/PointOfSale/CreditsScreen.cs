﻿// 
// Point of sale
//

// Versions:
// V0.08 19-Dic-2017 Nacho: Almost empty skeleton

using System;

class CreditsScreen
{
    public void Display()
    {
        Console.Write("Credits soon available. Press Enter to continue...");
        Console.ReadLine();
    }
}
