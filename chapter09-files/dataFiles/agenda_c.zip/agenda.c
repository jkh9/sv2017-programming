#include <stdio.h>     /* Entrada y salida est�ndar */
#include <string.h>    /* Manejo de cadenas de texto */
#include <io.h>        /* Funciones de ficheros */
#include <conio.h>     /* Acceso a la pantalla en Turbo C */

#define NOMBREF "agenda.dat"

typedef
    struct                          /*  Nuestro tipo de datos  */
    {
        char nombre[21];           /* 20 letras */
        char direccion[31];        /* 30 letras */
        char ciudad[16];           /* 15 letras */
        char cp[6];                /*  5 letras */
        char telef[13];            /* 12 letras */
        char observ[41];           /* 40 letras */
    }  tipoAgenda;



/* Declaraciones de variables globales */

FILE *fichAgenda;
tipoAgenda ficha;
int longFicha = sizeof (tipoAgenda);
int numFicha;
int ultima;
char opcion;


void pausa()              /*  ----- Espera a que se pulse una tecla  */
{
    getch();
};


void saludo()                   /*  ----- Cartelito de presentaci�n  */
{
    textbackground(BLACK); textcolor(LIGHTGRAY);
    clrscr();
    window(23,3,80,25);
    textcolor(LIGHTCYAN);
    cprintf("\r\n\r\n\r\n+------------------------------+\r\n");
    cprintf("|                              |__\r\n");
    cprintf("|                              |__\r\n");
    cprintf("|         A G E N D A          |__\r\n");
    cprintf("|                              |__\r\n");
    cprintf("|                              |__\r\n");
    cprintf("+------------------------------+__\r\n");
    cprintf("  ________________________________");
    textcolor(LIGHTGRAY);
    window(1,1,80,25);
    gotoxy(1,25);      /* Para que el cursor no moleste */
    pausa();
};


void escribe()              /*  ----- Escribe los datos en pantalla  */
{
    int i;

    clrscr();
    textcolor(WHITE);
    textbackground(BLUE);
    gotoxy(1,2);cprintf("          Agenda            (ficha actual: %d de %d)",
        numFicha, ultima);
    clreol();               /* Borro hasta el final de la l�nea en azul */
    gotoxy(1,3);
    for (i=1;i<=80;i++) cprintf("-");        /* 80 guiones */
    textbackground(BLACK);
    textcolor(LIGHTGRAY);

    /* Me coloco en la ficha que toca */
    fseek( fichAgenda, (numFicha-1)*longFicha, SEEK_SET );
    /* y la leo */
    fread( &ficha, longFicha, 1, fichAgenda);
    /* No usaremos fscanf para evitar problemas con comas y espacios */

    gotoxy(1,6);
    cprintf("Nombre:        %s\r\n\r\n", ficha.nombre);
    cprintf("Direccion:     %s\r\n\r\n", ficha.direccion);
    cprintf("Ciudad:        %s\r\n\r\n", ficha.ciudad);
    cprintf("Codigo Postal: %s\r\n\r\n", ficha.cp);
    cprintf("Telefono:      %s\r\n\r\n\r\n", ficha.telef);
    cprintf("Observaciones: %s\r\n",ficha.observ);

    textcolor(WHITE);
    textbackground(BLUE);
    gotoxy(1,23);
    for (i=1;i<=80;i++) cprintf("-");     /* 80 guiones */                                                          /*      Abajo: escribe las opciones      */
    gotoxy(1,24);
    cprintf(" 1-Anterior   2-Posterior   3-Numero    4-Anadir   5-Corregir    0-Terminar");
    clreol();
    textbackground(BLACK);
    textcolor(LIGHTGRAY);
};


void fichaNueva()                   /*  ----- A�ade una ficha nueva  */
{
    clrscr();
    textcolor(YELLOW);
    numFicha = ultima + 1;           /* Hay que escribir al final */
    cprintf("Anadiendo la ficha %d.",numFicha);
    textcolor(LIGHTGRAY);

    cprintf("\r\nNombre ?\r\n");  gets(ficha.nombre );
    cprintf("\r\nDireccion ?\r\n");  gets(ficha.direccion );
    cprintf("\r\nCiudad ?\r\n");  gets(ficha.ciudad );
    cprintf("\r\nCodigo Postal ?\r\n");  gets(ficha.cp );
    cprintf("\r\nTelefono ?\r\n");  gets(ficha.telef );
    cprintf("\r\nObservaciones ?\r\n");  gets(ficha.observ );

    fseek( fichAgenda, (numFicha-1)*longFicha, SEEK_SET );  /* Se sit�a      */
    fwrite( &ficha, longFicha, 1, fichAgenda);                    /* y escribe la ficha      */
    ultima ++;               /*  Ahora hay una m�s      */
};


void modifica()                  /*  ----- Modifica la ficha actual  */
{
    char temporal[100];     /* Almacena cada valor temporalmente */

    clrscr();
    textcolor(YELLOW);
    cprintf("Corrigiendo la ficha %d.",numFicha);
    textcolor(LIGHTGRAY);

    cprintf("\r\nNombre (%s) ?", ficha.nombre);  
    strcpy(temporal,"\0");      /* Muestro el valor anterior */
    gets(temporal);             /* y pido el nuevo */
    if (strlen(temporal))       /* Si se teclea algo, */
        strcpy(ficha.nombre, temporal);      /* lo modifico (si no, no cambia) */

    cprintf("\r\nDireccion (%s) ?", ficha.direccion);
    strcpy(temporal,"\0");
    gets(temporal);
    if (strlen(temporal))
        strcpy(ficha.direccion, temporal);

    cprintf("\r\nCiudad (%s) ?", ficha.ciudad);
    gets(temporal);
    if (strlen(temporal))
        strcpy(ficha.ciudad, temporal);

    cprintf("\r\nCodigo postal (%s) ?", ficha.cp);
    gets(temporal);
    if (strlen(temporal))
        strcpy(ficha.cp, temporal);

    cprintf("\r\nTelefono (%s) ?", ficha.telef);
    gets(temporal);
    if (strlen(temporal))
        strcpy(ficha.telef, temporal);

    cprintf("\r\nObservaciones (%s) ?", ficha.observ);
    gets(temporal);
    if (strlen(temporal))
        strcpy(ficha.observ, temporal);

    /* Finalmente, la guardo */
    fseek( fichAgenda, (numFicha-1)*longFicha, SEEK_SET );  
    fwrite( &ficha, longFicha, 1, fichAgenda);


}


void numeroFicha()     /*  ----- Va a la ficha con un cierto numero  */
{
    int numero;

    clrscr();
    textcolor(YELLOW);
    cprintf("Saltar a la ficha con un determinado numero ");
    textcolor(LIGHTGRAY);
    cprintf("\r\nQue numero de ficha ?");
    scanf("%d", &numero );
    if (numero>0)                 /* Compruebo que sea v�lido */
        if (numero<=ultima)
            numFicha=numero;      /* si es <= que la �ltima, salto */
         else
            numFicha=ultima;     /* si es mayor, me quedo en la �ltima */
};


void prepara()            /*  ----- Inicializaci�n de las variables  */
{                               /*  y apertura/creaci�n del fichero  */

    numFicha = 1;
    ultima = 0;

    fichAgenda = fopen (NOMBREF, "r+b");      /* Pruebo a abrir el fichero */
    if (fichAgenda == NULL)                   /* Si no existen datos */
    {
        clrscr();
        cprintf(" No existen datos.  Pulse una tecla para introducirlos.");
        pausa();
        fichAgenda = fopen (NOMBREF, "wb");   /* los creo */

        fichaNueva();                 /* y obligo a a�adir una ficha */
    }
    else
    {
        fseek( fichAgenda, 0, SEEK_END);
        ultima = ftell( fichAgenda ) / longFicha;  /* N�mero de fichas */
    }
};


int main()
{                               /*  ----- Cuerpo del programa -----  */
    saludo();
    prepara();
    do
    {
        escribe();

        opcion='a';
        do
            opcion = getch();
        while ((opcion<'0') || (opcion>'5'));

        switch (opcion)
        {
            case '1':        /* Ficha anterior */
               if (numFicha>1) numFicha--;
               break;
            case '2':        /* Ficha posterior */
               if (numFicha<ultima) numFicha++;
               break;
            case '3':        /* N�mero de ficha */
               numeroFicha();
               break;
            case '4':        /* A�adir una ficha */
               fichaNueva();
               break;
            case '5':        /* Corregir la ficha actual */
               modifica();
               break;
        };
    }
    while (opcion != '0');      /* Terminar */
    fclose( fichAgenda );
    clrscr();
    return 0;
}

